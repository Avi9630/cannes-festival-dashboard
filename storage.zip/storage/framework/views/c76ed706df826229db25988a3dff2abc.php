<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box bg-logo">
        <!-- Dark Logo-->
        <a href="<?php echo e(url('/')); ?>" class="logo">
            <img src="<?php echo e(asset('admin-iffi/images/nfdc-logo.png')); ?>" alt="" class="img-fluid"
                style=" width:110px">
        </a>
        <!-- Light Logo-->
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
            id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav mt-4" id="navbar-nav">
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(url('/')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">DASHBOARD</span>
                            </a>
                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-user')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarUser" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="sidebarUser">
                                    <i class="ri-user-2-line"></i> <span data-key="">USERS</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarUser">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('users.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-role')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarRole" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="sidebarRole">
                                    <i class="ri-user-follow-line"></i> <span data-key="">ROLE</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarRole">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('roles.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-permission')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#Permission" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="Permission">
                                    <i class="ri-lock-2-line"></i> <span data-key="">PERMISSION</span>
                                </a>
                                <div class="collapse menu-dropdown" id="Permission">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('permissions.index')); ?>" class="nav-link" data-key="">
                                                LIST </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-ip')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#indianPanoroma" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="indianPanoroma">
                                    <i class="ri-flag-2-line"></i> <span data-key="">INDIAN PANORAMA</span>
                                </a>
                                <div class="collapse menu-dropdown" id="indianPanoroma">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('ips.index')); ?>" class="nav-link" data-key="">LIST</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-ott')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#ott" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="ott">
                                    <i class="ri-play-circle-line"></i> <span data-key="">OTT</span>
                                </a>
                                <div class="collapse menu-dropdown" id="ott">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('otts.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-cmot')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#CMOT" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="CMOT">
                                    <i class="ri-folder-user-line"></i> <span data-key="">CMOT</span>
                                </a>
                                <div class="collapse menu-dropdown" id="CMOT">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('cmots.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-dd')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#DirectDebut" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="DirectDebut">
                                    <i class="ri-direction-line"></i> <span data-key="">DIRECTOR DEBUTE</span>
                                </a>
                                <div class="collapse menu-dropdown" id="DirectDebut">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('dds.index')); ?>" class="nav-link" data-key="">LIST</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master-list')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#Alumanis" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="Alumanis">
                                    <i class="ri-lightbulb-flash-line"></i> <span data-key="">ALUMNI</span>
                                </a>
                                <div class="collapse menu-dropdown" id="Alumanis">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('alumnis.index')); ?>" class="nav-link" data-key=""> MASTER LIST </a>
                                        </li>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recruiter-selected')): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('selected-list')); ?>" class="nav-link" data-key="">MY SELECTION</a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recruiter-rejected')): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('rejected-list')); ?>" class="nav-link" data-key="">MY REJECTION</a>
                                            </li>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cmot-participants-2024')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#CMOTParticipant" data-bs-toggle="collapse"
                                    role="button" aria-expanded="false" aria-controls="CMOTParticipant">
                                    <i class="ri-stack-line"></i> <span data-key="">2024 CMOT PARTICIPANTS
                                    </span>
                                </a>
                                <div class="collapse menu-dropdown" id="CMOTParticipant">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('cmot-participants.index')); ?>" class="nav-link"
                                                data-key=""> MASTER LIST </a>
                                        </li>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recruiter-selected')): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('cmot-participant-selected-list')); ?>" class="nav-link"
                                                    data-key=""> MY SELECTION </a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('recruiter-rejected')): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('cmot-participant-rejected-list')); ?>" class="nav-link"
                                                    data-key="">MY REJECTION </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(url('/')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">DASHBOARD</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(route('login')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">LOGIN</span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>

<div class="vertical-overlay"></div>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>