<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box bg-logo">
        <!-- Dark Logo-->
        <a href="<?php echo e(url('/')); ?>" class="logo">
            <img src="<?php echo e(asset('cannes/CANNES.png')); ?>" alt="" class="img-fluid" style="height: 60px">
            
        </a>
        <!-- Light Logo-->
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
            id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav mt-4" id="navbar-nav">
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(url('/')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">DASHBOARD</span>
                            </a>
                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-user')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarUser" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="sidebarUser">
                                    <i class="ri-user-2-line"></i> <span data-key="">USERS</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarUser">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('users.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-role')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarRole" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="sidebarRole">
                                    <i class="ri-user-follow-line"></i> <span data-key="">ROLE</span>
                                </a>
                                <div class="collapse menu-dropdown" id="sidebarRole">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('roles.index')); ?>" class="nav-link" data-key="">LIST
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-permission')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#Permission" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="Permission">
                                    <i class="ri-lock-2-line"></i> <span data-key="">PERMISSION</span>
                                </a>
                                <div class="collapse menu-dropdown" id="Permission">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('permissions.index')); ?>" class="nav-link" data-key="">
                                                LIST </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cannes-entries-list')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#nfaFeature" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="indianPanoroma">
                                    <i class="ri-flag-2-line"></i> <span data-key="">CANNES ENTRIES</span>
                                </a>
                                <div class="collapse menu-dropdown" id="nfaFeature">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('cannes-entries-list')); ?>" class="nav-link"
                                                data-key="">LIST</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cannes-selected-list')): ?>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#nfaNonFeature" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="indianPanoroma">
                                    <i class="ri-flag-2-line"></i> <span data-key="">CANNES SELECTED ENTRIES</span>
                                </a>
                                <div class="collapse menu-dropdown" id="nfaNonFeature">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('cannes-selected-list')); ?>" class="nav-link"
                                                data-key="">LIST</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>

                        
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(url('/')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">DASHBOARD</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(route('login')); ?>">
                                <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">LOGIN</span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>

<div class="vertical-overlay"></div>
<?php /**PATH C:\xampp\htdocs\cannes-festival-dashboard\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>