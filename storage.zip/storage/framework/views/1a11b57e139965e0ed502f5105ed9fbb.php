<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? 'Page Title'); ?></title>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    

</head>

<body>
    <h1>LIVE-WIRE</h1>
    <?php echo e($slot); ?>


    
    <script src="public/vendor/livewire/livewire.js"></script>
    
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>