<!-- Footer -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <script>
                    document.write(new Date().getFullYear())
                </script> © iffigoa.
            </div>
        </div>
    </div>
</footer>
<!-- Footer Ends -->
</div>
<!-- end main content-->
</div>
<!-- END layout-wrapper -->
<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('admin-iffi/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/feather.min.js')); ?>"></script>
<!-- App js -->
<script src="<?php echo e(asset('admin-iffi/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/common.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\nfa-dashboard\resources\views/layouts/footer.blade.php ENDPATH**/ ?>