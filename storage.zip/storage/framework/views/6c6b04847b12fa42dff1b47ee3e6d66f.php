<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php if(Auth::user()->hasAnyRole(['SUPERADMIN', 'ADMIN'])): ?>
                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Feature Film Entry</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-success text-success fs-17 rounded">
                                    <i class="ri-flag-2-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total forms submitted</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalFeature) && !empty($totalFeature) ? $totalFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total paid </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($paidFeature) && !empty($paidFeature) ? $paidFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Non-Feature Film Entry</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-success text-success fs-17 rounded">
                                    <i class="ri-flag-2-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total forms submitted</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalNonFeature) && !empty($totalNonFeature) ? $totalNonFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total paid </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($paidNonFeature) && !empty($paidNonFeature) ? $paidNonFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Best Book On Cinema</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-warning text-warning fs-17 rounded">
                                    <i class="ri-folder-user-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total entries</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total completed</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Best Book On Cinema</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-warning text-warning fs-17 rounded">
                                    <i class="ri-folder-user-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total entries</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total completed</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php elseif(Auth::user()->hasRole('PRODUCER')): ?>
                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Feature Film Entry</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-success text-success fs-17 rounded">
                                    <i class="ri-flag-2-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total forms submitted</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalFeature) && !empty($totalFeature) ? $totalFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total paid </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($paidFeature) && !empty($paidFeature) ? $paidFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Non-Feature Film Entry</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-success text-success fs-17 rounded">
                                    <i class="ri-flag-2-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total forms submitted</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalNonFeature) && !empty($totalNonFeature) ? $totalNonFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total paid </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($paidNonFeature) && !empty($paidNonFeature) ? $paidNonFeature : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php elseif(Auth::user()->hasAnyRole(['PUBLISHER'])): ?>
                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Best Book On Cinema</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-warning text-warning fs-17 rounded">
                                    <i class="ri-folder-user-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total entries</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total completed</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                
                <div class="col-md-4 col-sm-4 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Best Book On Cinema</h4>
                        </div>
                        <div class="card-body">
                            <div class="avatar-sm mb-1">
                                <div class="avatar-title bg-soft-warning text-warning fs-17 rounded">
                                    <i class="ri-folder-user-line"></i>
                                </div>
                            </div>
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total entries</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total completed</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <h1>You don't have access to see this dashboard....</h1>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nfa-dashboard\resources\views/welcome.blade.php ENDPATH**/ ?>