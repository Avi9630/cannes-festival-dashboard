<?php $__env->startSection('title'); ?>
    <?php echo e('Permissions List'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
            <div class=" g-4">
                <div>
                    <form class="filter-project" method="GET" action="<?php echo e(route('permissions.search')); ?>"><?php echo csrf_field(); ?>
                        <?php echo method_field('GET'); ?>
                        <div class="col-md-6 mx-auto">
                            <div class="row">
                                <div class="col-xxl-6 col-md-8">
                                    <label for="basiInput" class="form-label">Search</label>
                                    <input type="text" name="search" class="form-control" value="<?php echo e(isset($payload['search']) ? $payload['search'] : ''); ?>" placeholder="Search">
                                </div>
                                <div class="col-xxl-4 col-md-4">
                                    <label for="basiInput" class="form-label w-100">&nbsp;</label>
                                    <button class="btn common-btn "><i class="ri-search-line search-icon"></i>
                                        Search</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="text-end">
                        <a href="<?php echo e(route('permissions.index')); ?>" class="btn common-btn">RESET</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 d-flex">
                <div class="card card-animate w-100 ">
                    <div class="card-header">
                        <h4 class="card-title mb-0 project-title">
                            PERMISSIONS
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-permission')): ?>
                                <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-sm btn-warning">Create</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <span>
                            <h4 class="alert-danger"></h4>
                        </span>
                        <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has($msg)): ?>
                                <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                    <?php echo e(Session::get($msg)); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="table table-responsive">
                            <table class="table">
                                <?php if(count($permissions) > 0): ?>
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr.No</th>
                                            <th scope="col">Name</th>
                                            <th scope="col" width="100">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td> <?php echo e($key + 1); ?> </td>
                                                <td> <?php echo e($permission['name']); ?> </td>

                                                <td class="action-btn">
                                                    <div class="view-edit-delete">
                                                        
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-permission')): ?>
                                                            <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>"><i
                                                                    class="ri-pencil-fill "></i>
                                                            </a>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-permission')): ?>
                                                            <form action="<?php echo e(route('permissions.destroy', [$permission->id])); ?>"
                                                                method="post" style="display: inline"
                                                                onsubmit="return confirmDelete()">
                                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                <button type="submit " class="deletebtn">
                                                                    <i class="ri-delete-bin-fill "></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                <?php else: ?>
                                    <p>No record found...!!</p>
                                <?php endif; ?>
                            </table>
                        </div>
                        <!-- Pagination -->
                        
                        <!-- Pagination End-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nfa-dashboard\resources\views/permissions/index.blade.php ENDPATH**/ ?>