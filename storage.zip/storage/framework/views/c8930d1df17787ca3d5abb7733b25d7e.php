<div>
    <h1><?php echo e($count); ?></h1>

    <button wire:click="increment">+</button>

    <button wire:click="decrement">-</button>
</div>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/livewire/counter.blade.php ENDPATH**/ ?>