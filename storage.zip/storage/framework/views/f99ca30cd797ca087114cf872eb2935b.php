<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 stretch-card">
                    

                    <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has($msg)): ?>
                            <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                <?php echo e(Session::get($msg)); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                    

                    
                    

                    <?php if((Auth::check() && Auth::user()->hasRole('SUPERADMIN')) || Auth::user()->hasRole('GRANDJURY')): ?>

                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">JURY SCORES</h4>
                            </div>
                            <div class="card-body">
                                <p style="background-color: yellow">Would you recommend these films for market screening at
                                    Marche du Film,
                                    Cannes Film Festival?</p>

                                <div class="card">
                                    <div class="card-body">
                                        <div class="row pt-2">
                                            <?php if(isset($juryScores) && !empty($juryScores) && count($juryScores) > 0): ?>
                                                <table class="table custom-table">
                                                    <thead>
                                                        <tr>
                                                            <th>Jury Name</th>
                                                            <th>Overall Score</th>
                                                            <th>Feedback</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $juryScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td> <?php echo e($score->user->name ?? ''); ?> </td>
                                                                <td> <?php echo e($score->overall_score ?? ''); ?> </td>
                                                                <td> <?php echo e($score->feedback ?? ''); ?> </td>
                                                                <td>
                                                                    <a href="<?php echo e(route('selected-by-grand', $score->festival_entry_id)); ?>"
                                                                        class="btn btn-sm btn-primary" title="">
                                                                        Select
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <p>Marks not given by Jury.!!</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cannes-festival-dashboard\resources\views/grand-jury/show.blade.php ENDPATH**/ ?>