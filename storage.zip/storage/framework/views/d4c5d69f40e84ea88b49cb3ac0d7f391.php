<script src="<?php echo e(asset('public/admin-iffi/js/bootstrap.bundle.min.js')); ?>"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>
<script src="<?php echo e(asset('admin-iffi/js/particles.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/particles.app.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/password-addon.init.js')); ?>"></script>
<script src="<?php echo e(asset('admin-iffi/js/common.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/auth/layouts/footer.blade.php ENDPATH**/ ?>