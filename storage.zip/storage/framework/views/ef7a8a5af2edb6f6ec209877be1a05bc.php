<form wire:submit="search" method="GET" class="filter-project"><?php echo csrf_field(); ?> <?php echo method_field('GET'); ?>
    <div class="row">
        <div class="col-md-6">
            <label for="role_id" class="form-label">Select Role</label>
            <select name="role_id" class="form-select">
                <option value="">Select role</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option name="role_id" value="<?php echo e($role->id); ?>"
                        <?php echo e(isset($payload['role_id']) && $payload['role_id'] == $role->id ? 'selected' : ''); ?>>
                        <?php echo e($role->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div class="col-xxl-2 col-md-2">
            <label for="basiInput" class="form-label w-100">&nbsp;</label>
            <button class="btn common-btn  w-100"><i class="ri-search-line search-icon"></i>
                Search</button>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/livewire/users/search-user.blade.php ENDPATH**/ ?>