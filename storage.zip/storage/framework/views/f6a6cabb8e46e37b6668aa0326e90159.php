<div>


    <div class="table table-responsive">
        <table class="table">
            <!--[if BLOCK]><![endif]--><?php if(count($users) > 0): ?>
                <thead>
                    <tr>
                        <th scope="col">Sr.No</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Roles</th>
                        <th scope="col" width='100'>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th> <?php echo e($user->id); ?> </th>
                            <td> <?php echo e($user['name']); ?> </td>
                            <td> <?php echo e($user['email']); ?> </td>
                            <td> <?php echo e($user['mobile']); ?> </td>

                            <td>
                                <!--[if BLOCK]><![endif]--><?php if($user->getRoleNames()->isEmpty()): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign-role')): ?>
                                        <a href="<?php echo e(url('assign_role', $user->id)); ?>"
                                            class="btn btn-sm btn-success">ASSIGN-ROLE</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($user->getRoleNames()->implode('", "')); ?>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>

                            <td class="action-btn">
                                <div class="view-edit-delete">
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>"><i class="ri-pencil-fill "></i>
                                        </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post"
                                            style="display: inline" onsubmit="return confirmDelete()">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit " class="deletebtn">
                                                <i class="ri-delete-bin-fill "></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            <?php else: ?>
                <p>No record found...!!</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </table>
    </div>

    <!-- Pagination -->
    <nav aria-label="...">
        <ul class="pagination">
            <?php echo e($users->withQueryString()->links()); ?>

        </ul>
    </nav>
    <!-- Pagination End-->
</div>
<?php /**PATH C:\xampp\htdocs\nfdc-admin-dashboard\resources\views/livewire/users/users.blade.php ENDPATH**/ ?>