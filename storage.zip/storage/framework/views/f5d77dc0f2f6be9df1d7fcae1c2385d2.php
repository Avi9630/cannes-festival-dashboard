<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-body-wrapper">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 stretch-card">
                    <div class="card">

                        <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has($msg)): ?>
                                <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                    <?php echo e(Session::get($msg)); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="card-header">
                            <div class="float-end">
                                <a href="<?php echo e(route('cannes-entries-list')); ?>" class="btn btn-sm btn-warning">&larr; Back</a>
                            </div>
                            <h4 class="card-title">PREVIEW</h4>
                        </div>

                        <div class="card-body">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row pt-2">

                                        <div class="col-md-4">
                                            <p><strong>Full Name : </strong> <?php echo e($festival->NAME ?? ''); ?></p>
                                        </div>

                                        <?php if(Auth::check() && !Auth::user()->hasRole('RECRUITER')): ?>
                                            <div class="col-md-4">
                                                <p><strong>Email : </strong> <?php echo e($festival->email ?? ''); ?></p>
                                            </div>

                                            <div class="col-md-4">
                                                <p><strong>Mobile : </strong> <?php echo e($festival->mobile ?? ''); ?></p>
                                            </div>
                                        <?php endif; ?>

                                        <div class="col-md-4">
                                            <p><strong>Film Title : </strong> <?php echo e($festival->film_title ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Film Title English : </strong>
                                                <?php echo e($festival->film_title_english ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Language : </strong> <?php echo e($festival->LANGUAGE ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Producer Name : </strong> <?php echo e($festival->producer_name ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Producetion Company : </strong>
                                                <?php echo e($festival->production_company ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Screener Link : </strong> <?php echo e($festival->screener_link ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Film Link : </strong>
                                                <a href="<?php echo e($festival->film_link ?? ''); ?>"
                                                    target="_blank"><?php echo e($festival->film_link ?? ''); ?>

                                                </a>
                                            </p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Password : </strong> <?php echo e($festival->PASSWORD ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Director Name : </strong> <?php echo e($festival->director_name ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Synopsis : </strong> <?php echo e($festival->synopsis ?? ''); ?></p>
                                        </div>

                                        <div class="col-md-4">
                                            <p><strong>Director Bio : </strong> <?php echo e($festival->director_bio ?? ''); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex" style="margin-left:400px; margin-top: 15px;">
                                <?php if(Auth::check() && Auth::user()->hasRole('JURY')): ?>
                                    <a href="<?php echo e(url('score-by', $festival->id)); ?>" class="btn btn-sm btn-primary"
                                        style="margin-right: 5px;">
                                        Your Scors
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <br>
                    </div>
                    <?php if((Auth::check() && Auth::user()->hasRole('SUPERADMIN')) || Auth::user()->hasRole('ADMIN')): ?>
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">JURY SCORES</h4>
                            </div>
                            <div class="card-body">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row pt-2">
                                            <?php if(isset($juryScores) && !empty($juryScores) && count($juryScores) > 0): ?>
                                                <table class="table custom-table">
                                                    <thead>
                                                        <tr>
                                                            
                                                            <th>Jury Name</th>
                                                            <th>Overall Score</th>
                                                            <th>Feedback</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $juryScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                
                                                                <td> <?php echo e($score->user->name ?? ''); ?> </td>
                                                                <td> <?php echo e($score->overall_score ?? ''); ?> </td>
                                                                <td> <?php echo e($score->feedback ?? ''); ?> </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <p>Marks not given by Jury.!!</p>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cannes-festival-dashboard\resources\views/festival-entry/show.blade.php ENDPATH**/ ?>