<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php if(Auth::user()->hasAnyRole(['SUPERADMIN', 'ADMIN'])): ?>
                <div class="col-md-12 col-sm-12 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">CANNES ENTRY</h4>
                        </div>
                        <div class="card-body">
                            
                            <ul class="list-group border-none mb-1">

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total entries</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalEntries) && !empty($totalEntries) ? $totalEntries : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total assigned to jury</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalAssignedToJury) && !empty($totalAssignedToJury) ? $totalAssignedToJury : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total scored by Jury</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalScoreByJury) && !empty($totalScoreByJury) ? $totalScoreByJury : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total selected by Grandjury </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalSelectByGrandJury) && !empty($totalSelectByGrandJury) ? $totalSelectByGrandJury : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-12">
                    <div style="height: 400px; width: 100%;">
                        <canvas id="paymentChart"></canvas>
                    </div>
                </div>
                <div class="col-md-2"></div>
            <?php elseif(Auth::user()->hasRole('JURY')): ?>
                <div class="col-md-12 col-sm-12 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">CANNES ENTRY</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total assigned</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalAssign) && !empty($totalAssign) ? $totalAssign : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total pending by you </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($pendingByYou) && !empty($pendingByYou) ? $pendingByYou : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total scored by you </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($scoreByYou) && !empty($scoreByYou) ? $scoreByYou : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-12">
                    <div style="height: 400px; width: 100%;">
                        <canvas id="paymentChartJury"></canvas>
                    </div>
                </div>
                <div class="col-md-2"></div>
            <?php elseif(Auth::user()->hasRole('GRANDJURY')): ?>
                <div class="col-md-12 col-sm-12 d-flex">
                    <div class="card card-animate w-100 ">
                        <div class="card-header">
                            <h4 class="card-title mb-0">CANNES ENTRY</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group border-none mb-1">
                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total scored by Jury</h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalScoreByJury) && !empty($totalScoreByJury) ? $totalScoreByJury : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>

                                <li class="list-group-item">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-grow-1">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 ">
                                                    <h6 class="fs-14 mb-0">Total selected by you </h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0 ">
                                            <span class="badge text-bg-primary">
                                                <?php echo e(isset($totalSelectByGrandJury) && !empty($totalSelectByGrandJury) ? $totalSelectByGrandJury : ''); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-12">
                    <div style="height: 400px; width: 100%;">
                        <canvas id="paymentChartGrandJury"></canvas>
                    </div>
                </div>
                <div class="col-md-2"></div>
            <?php else: ?>
                <h1>You don't have access to see this dashboard....</h1>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <script>
        const ctx = document.getElementById('paymentChart').getContext('2d');
        const paymentChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [
                    'Total Entries',
                    'Total Assigned To Jury',
                    'Total Scored By Jury',
                    'Total Selected By Grand Jury'
                ],
                datasets: [{
                    label: 'Entry Status',
                    data: [
                        <?php echo e($totalEntries ?? 0); ?>,
                        <?php echo e($totalAssignedToJury ?? 0); ?>,
                        <?php echo e($totalScoreByJury ?? 0); ?>,
                        <?php echo e($totalSelectByGrandJury ?? 0); ?>

                    ],
                    backgroundColor: [
                        '#007bff',
                        '#ffc107',
                        '#28a745',
                        '#dc3545'
                    ],
                    borderColor: [
                        '#ffffff',
                        '#ffffff',
                        '#ffffff',
                        '#ffffff'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Festival Entry Status'
                    }
                }
            }
        });
    </script>
    
    <script>
        const ctx = document.getElementById('paymentChartGrandJury').getContext('2d');
        const paymentChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [
                    'Total Scored By Jury',
                    'Total Selected By Grand Jury'
                ],
                datasets: [{
                    label: 'Entry Status',
                    data: [
                        <?php echo e($totalScoreByJury ?? 0); ?>,
                        <?php echo e($totalSelectByGrandJury ?? 0); ?>

                    ],
                    backgroundColor: [
                        '#28a745', // Green for Scored
                        '#dc3545' // Red for Selected
                    ],
                    borderColor: [
                        '#ffffff',
                        '#ffffff'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Festival Entry Status'
                    }
                }
            }
        });
    </script>
    

    <script>
        const ctx = document.getElementById('paymentChartJury').getContext('2d');
        const paymentChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [
                    // 'Total Entries',
                    'Total Assigned',
                    'Total pending by you',
                    'Total scored by you'
                ],
                datasets: [{
                    label: 'Entry Status',
                    data: [
                        <?php echo e($totalAssign ?? 0); ?>,
                        <?php echo e($pendingByYou ?? 0); ?>,
                        <?php echo e($scoreByYou ?? 0); ?>,
                        // <?php echo e($totalSelectByGrandJury ?? 0); ?>

                    ],
                    backgroundColor: [
                        '#007bff',
                        '#ffc107',
                        '#28a745',
                        // '#dc3545'
                    ],
                    borderColor: [
                        '#ffffff',
                        '#ffffff',
                        '#ffffff',
                        // '#ffffff'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: 'Festival Entry Status'
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cannes-festival-dashboard\resources\views/welcome.blade.php ENDPATH**/ ?>