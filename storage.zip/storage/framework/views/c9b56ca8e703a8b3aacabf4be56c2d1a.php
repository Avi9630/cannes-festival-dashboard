<?php $__env->startSection('title'); ?>
    <?php echo e('User List'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
            <div class="g-4">
                <div>
                    <form action="<?php echo e(route('user.search')); ?>" method="GET" class="filter-project"><?php echo csrf_field(); ?> <?php echo method_field('GET'); ?>
                        <div class="row">

                            
                            

                            <div class="col-md-6">
                                <label for="role_id" class="form-label">Select Role</label>
                                <select name="role_id" class="form-select">
                                    <option value="">Select role</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option name="role_id" value="<?php echo e($role->id); ?>"
                                            <?php echo e(isset($payload['role_id']) && $payload['role_id'] == $role->id ? 'selected' : ''); ?>>
                                            <?php echo e($role->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-xxl-2 col-md-2">
                                <label for="basiInput" class="form-label w-100">&nbsp;</label>
                                <button class="btn common-btn  w-100"><i class="ri-search-line search-icon"></i>
                                    Search</button>
                            </div>
                        </div>
                    </form>
                    <div class="text-end">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn common-btn">RESET</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-sm-12 d-flex">
                <div class="card card-animate w-100 ">
                    <div class="card-header">
                        <h4 class="card-title mb-0 project-title">
                            USERS
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-user')): ?>
                                <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-warning">CREATE</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <span>
                            <h4 class="alert-danger"></h4>
                        </span>
                        <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has($msg)): ?>
                                <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                    <?php echo e(Session::get($msg)); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="table table-responsive">
                            <table class="table">
                                <?php if(count($users) > 0): ?>
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr.No</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Roles</th>
                                            <th scope="col" width='100'>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th> <?php echo e($user->id); ?> </th>
                                                <td> <?php echo e($user['name']); ?> </td>
                                                <td> <?php echo e($user['email']); ?> </td>
                                                <td> <?php echo e($user['mobile']); ?> </td>

                                                <td>
                                                    <?php if($user->getRoleNames()->isEmpty()): ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign-role')): ?>
                                                            <a href="<?php echo e(url('assign_role', $user->id)); ?>"
                                                                class="btn btn-sm btn-success">ASSIGN-ROLE</a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php echo e($user->getRoleNames()->implode('", "')); ?>

                                                    <?php endif; ?>
                                                </td>

                                                <td class="action-btn">
                                                    <div class="view-edit-delete">
                                                        
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
                                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>"><i
                                                                    class="ri-pencil-fill "></i>
                                                            </a>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
                                                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                                                method="post" style="display: inline"
                                                                onsubmit="return confirmDelete()">
                                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                                <button type="submit " class="deletebtn">
                                                                    <i class="ri-delete-bin-fill "></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                <?php else: ?>
                                    <p>No record found...!!</p>
                                <?php endif; ?>
                            </table>
                        </div>
                        <!-- Pagination -->
                        <nav aria-label="...">
                            <ul class="pagination">
                                <?php echo e($users->withQueryString()->links()); ?>

                            </ul>
                        </nav>
                        <!-- Pagination End-->
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nfa-dashboard\resources\views/users/index.blade.php ENDPATH**/ ?>