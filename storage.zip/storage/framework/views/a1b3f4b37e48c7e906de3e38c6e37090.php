<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can-search')): ?>
            <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
                <div class="g-4">
                    <div>
                        <form action="<?php echo e(route('cannes-entries-search')); ?>" method="GET" class="filter-project"><?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <div class="row">

                                <?php
                                    $years = [
                                        1 => '2025',
                                        2 => '2024',
                                    ];
                                ?>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="year"><strong>Year</strong></label>
                                        <select name="year" class="form-select">
                                            <option value="">Select year</option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"
                                                    <?php echo e(isset($payload['year']) && $payload['year'] == $key ? 'selected' : ''); ?>>
                                                    <?php echo e($value); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6 from_date" id="fromDateField">
                                    <div class="mb-3">
                                        <label for="from_date" class="form-label"><strong>From Date</strong></label>
                                        

                                        <input type="text" name="from_date" id="from_date" class="form-control"
                                            value="<?php echo e(isset($payload['from_date']) ? $payload['from_date'] : ''); ?>"
                                            placeholder="Please select date">
                                    </div>
                                </div>

                                <div class="col-md-6 to_date" id="toDateField">
                                    <div class="mb-3">
                                        <label for="email"><strong>To Date</strong></label>
                                        

                                        <input type="text" name="to_date" id="to_date" class="form-control"
                                            value="<?php echo e(isset($payload['to_date']) ? $payload['to_date'] : ''); ?>"
                                            placeholder="Please select date">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <label for="name" class="form-label w-100">&nbsp;</label>
                                    <button type="submit" class="btn common-btn">SEARCH</button>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export-search')): ?>
                                        <a href="<?php echo e(route('export.cannes-search')); ?>" class="btn common-btn">
                                            SEARCH-EXPORT</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>

                        <div class="text-end">
                            <a href="<?php echo e(route('cannes-entries-list')); ?>" class="btn common-btn">RESET</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export')): ?>
                                <a href="<?php echo e(route('cannes-entries-export')); ?>" class="btn common-btn">EXPORT-ALL </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12 col-sm-12 d-flex">
                <div class="card card-animate w-100 ">

                    <div class="card-header">
                        <h4 class="card-title mb-0 project-title">
                            CANNES ENTRIES (COUNT :- <?php echo e(isset($count) ? $count : ''); ?>)
                        </h4>
                    </div>

                    <div class="card-body">

                        <span>
                            <h4 class="alert-danger"></h4>
                        </span>

                        <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has($msg)): ?>
                                <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                    <?php echo e(Session::get($msg)); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="table table-responsive">
                            <table class="table custom-table">
                                <?php if(count($entries) > 0): ?>
                                    <thead>
                                        <tr>
                                            
                                            
                                            <th>Ref.No</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign')): ?>
                                                <th>Assign</th>
                                            <?php endif; ?>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                

                                                

                                                <td> <?php echo e($entry->id); ?> </td>

                                                <td> <?php echo e($entry->NAME ?? ''); ?> </td>

                                                <td><?php echo e($entry->email ?? ''); ?></td>

                                                <td><?php echo e($entry->mobile ?? ''); ?></td>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign')): ?>
                                                    <td>
                                                        <?php if($entry->stage === '0' || $entry->stage === null): ?>
                                                            <?php
                                                                $juryRole = Spatie\Permission\Models\Role::where(
                                                                    'name',
                                                                    'jury',
                                                                )->first();
                                                                $users = App\Models\User::whereHas('roles', function (
                                                                    $query,
                                                                ) use ($juryRole) {
                                                                    $query->where('id', $juryRole->id);
                                                                })->get();
                                                            ?>
                                                            <form action="<?php echo e(url('assign_to', $entry->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                                                                <select name="user_id" id="user_id"
                                                                    class="form-select <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                    <option value="" selected>Select Jury</option>
                                                                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                        <option value="<?php echo e($user->id); ?>"
                                                                            <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                                                            <?php echo e($user->name); ?></option>
                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <?php endif; ?>
                                                                </select>
                                                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <button type="submit" id="submitButton"
                                                                    class="btn btn-sm btn-info">Assign</button>
                                                            </form>
                                                        <?php elseif($entry->stage === 1): ?>
                                                            <p style="color: blueviolet">Assigned to jury</p>
                                                        <?php elseif($entry->stage === 2): ?>
                                                            <p style="color: blueviolet">Score submitted by jury</p>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view')): ?>
                                                        <a href="<?php echo e(route('cannes-entries.view', $entry->id)); ?>">
                                                            <i class="ri-eye-fill black-text"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                <?php else: ?>
                                    <p>No record found...!!</p>
                                <?php endif; ?>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <nav aria-label="...">
                            <ul class="pagination">
                                <?php echo e($entries->withQueryString()->links()); ?>

                            </ul>
                        </nav>
                        <!-- Pagination End-->

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>

    <script>
        $(document).ready(function() {
            function toggleDateFields() {
                var selectedYear = $('select[name="year"]').val();
                if (selectedYear != '1') {
                    $('.from_date').hide();
                    $('.to_date').hide();
                } else {
                    $('.from_date').show();
                    $('.to_date').show();
                }
            }
            toggleDateFields();
            $('select[name="year"]').change(function() {
                toggleDateFields();
            });
        });
    </script>

    <script>
        $(function() {
            var minAllowedDate = new Date(2025, 0, 1);
            // Set up datepickers
            $("#from_date").datepicker({
                dateFormat: "yy-mm-dd",
                minDate: minAllowedDate,
                onClose: function(selectedDate) {
                    $("#to_date").datepicker("option", "minDate", selectedDate);
                }
            });

            $("#to_date").datepicker({
                dateFormat: "yy-mm-dd",
                onClose: function(selectedDate) {
                    $("#from_date").datepicker("option", "maxDate", selectedDate);
                }
            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cannes-festival-dashboard\resources\views/festival-entry/index.blade.php ENDPATH**/ ?>