<?php $__env->startSection('title'); ?>
    <?php echo e('BEST-FILM-CRITIC-LIST'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
            <div class="g-4">
                <div>
                    <form action="<?php echo e(route('best-film-critic-search')); ?>" method="GET" class="filter-project"><?php echo csrf_field(); ?>
                        <?php echo method_field('GET'); ?>
                        <div class="row">

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label"><strong>From Date</strong></label>
                                    <input type="date" name="from_date" class="form-control"
                                        value="<?php echo e(isset($payload['from_date']) ? $payload['from_date'] : ''); ?>"
                                        placeholder="Please select date">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email"><strong>To Date</strong></label>
                                    <input type="date" name="to_date" class="form-control"
                                        value="<?php echo e(isset($payload['to_date']) ? $payload['to_date'] : ''); ?>"
                                        placeholder="Please select date">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="payment_status"><strong>Payment status</strong></label>
                                    <select name="payment_status" id="payment_status" class="form-select">
                                        <option value="">Select status</option>
                                        <?php $__currentLoopData = $paids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"
                                                <?php echo e(isset($payload['payment_status']) && $payload['payment_status'] == $key ? 'selected' : ''); ?>>
                                                <?php echo e($value); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6" id="step-selection" style="display: none;">
                                <div class="mb-3">
                                    <label for="payment_status"><strong>Select steps</strong></label>
                                    <select name="step" class="form-select">
                                        <option value="">Select status</option>
                                        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"
                                                <?php echo e(isset($payload['step']) && $payload['step'] == $key ? 'selected' : ''); ?>>
                                                <?php echo e($value); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <label for="name" class="form-label w-100">&nbsp;</label>
                                <button type="submit" class="btn common-btn">SEARCH</button>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ip-non_featured_download')): ?>
                                    <a href="<?php echo e(route('best-film-critic-export-search')); ?>" class="btn common-btn">
                                        SEARCH-EXPORT
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>

                    <div class="text-end">
                        <a href="<?php echo e(route('best-film-critic')); ?>" class="btn common-btn">RESET</a>
                        <a href="<?php echo e(route('best-film-critic-export-all')); ?>" class="btn common-btn">
                            EXPORT-ALL
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 d-flex">
                <div class="card card-animate w-100 ">

                    <div class="card-header">
                        <h4 class="card-title mb-0 project-title">
                            BEST FILM CRITIC (COUNT :- <?php echo e(isset($count) ? $count : ''); ?>)
                        </h4>
                    </div>

                    <div class="card-body">

                        <span>
                            <h4 class="alert-danger"></h4>
                        </span>

                        <?php $__currentLoopData = ['success', 'info', 'danger', 'warning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has($msg)): ?>
                                <div id="flash-message" class="alert alert-<?php echo e($msg); ?>" role="alert">
                                    <?php echo e(Session::get($msg)); ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="table table-responsive">
                            <table class="table custom-table">
                                <?php if(count($bestFilmCritics) > 0): ?>
                                    <thead>
                                        <tr>
                                            <th>PDF</th>
                                            <th>ZIP</th>
                                            <th>Movie Ref</th>
                                            <th>Steps</th>
                                            <th>Client Name</th>
                                            <th>Client Email</th>
                                            <th>Writer Name</th>
                                            <th>Article Title</th>
                                            <th>Article Language</th>
                                            <th>Publication Date</th>
                                            <th>Publication Name</th>
                                            <th>Critic Name</th>
                                            <th>Critic Address</th>
                                            <th>Critic Contact</th>
                                            <th>Critic Nationality</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bestFilmCritics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bestFilmCritic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(route('ip.pdf', ['id' => $bestFilmCritic->id])); ?>"
                                                        class="text-danger" target="_blank">
                                                        <i class="ri-file-pdf-line"></i>
                                                    </a>
                                                </td>

                                                <td>
                                                    <a href="<?php echo e(route('ip.zip', ['id' => $bestFilmCritic->id])); ?>"
                                                        class="text-danger"><i class="ri-folder-zip-line"></i>
                                                    </a>
                                                </td>

                                                <td> <?php echo e($bestFilmCritic->id); ?> </td>

                                                <td>
                                                    <?php $__currentLoopData = $bestFilmCritic::stepsBestFilmCritic(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e(isset($bestFilmCritic->step) && $bestFilmCritic->step === $value ? ($key === 'SUBMISSION' ? 'PAID' : $key) : ''); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>

                                                <?php
                                                    $fullName =
                                                        $bestFilmCritic->client->first_name .
                                                        ' ' .
                                                        $bestFilmCritic->client->last_name;
                                                ?>

                                                <td><?php echo e($fullName ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->client->email ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->writer_name); ?></td>

                                                <td><?php echo e($bestFilmCritic->article_title); ?></td>

                                                <td><?php echo e($bestFilmCritic->article_language); ?></td>

                                                <td><?php echo e($bestFilmCritic->publication_date ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->publication_name ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->critic_name ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->critic_address ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->critic_contact ?? ''); ?></td>

                                                <td><?php echo e($bestFilmCritic->critic_indian_nationality === 1 ? 'Indian' : null); ?>

                                                </td>

                                                <?php
                                                    // $payment = App\Models\Transaction::where([
                                                    //     'website_type' => 1,
                                                    //     'client_id' => $feature['client_id'],
                                                    //     'context_id' => $feature['id'],
                                                    //     'auth_status' => '0300',
                                                    // ])->first();

                                                    // if (!is_null($payment)) {
                                                    //     $paymentDate = $payment->payment_date;
                                                    //     $paymentAmount = $payment->amount;
                                                    //     $paymentReceipt = $payment->bank_ref_no;
                                                    // } else {
                                                    //     $paymentDate = '';
                                                    //     $paymentAmount = '';
                                                    //     $paymentReceipt = '';
                                                    // }
                                                ?>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                <?php else: ?>
                                    <p>No record found...!!</p>
                                <?php endif; ?>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <nav aria-label="...">
                            <ul class="pagination">
                                <?php echo e($bestFilmCritics->withQueryString()->links()); ?>

                            </ul>
                        </nav>
                        <!-- Pagination End-->

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\nfa-dashboard\resources\views/best-film-critic/index.blade.php ENDPATH**/ ?>